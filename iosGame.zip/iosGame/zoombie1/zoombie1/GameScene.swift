//
//  GameScene.swift
//  zoombie1
//
//  Created by MacStudent on 2019-02-07.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    // Make zombie global, so other functions can access it
    let zombie:SKSpriteNode = SKSpriteNode(imageNamed:"zombie1")
    var dt: TimeInterval = 0
    
    
    override func didMove(to view: SKView) {
        // Set the background color of the app
        self.backgroundColor = SKColor.white;
        
        // -----------------------------
        // Add a background to the game
        // -----------------------------
        // Add a background image
        let bg = SKSpriteNode(imageNamed:"background1")
        // Set position of background to middle of screen
        bg.position = CGPoint(x: size.width/2, y: size.height/2)
        
        bg.anchorPoint = CGPoint.zero;
        bg.position = CGPoint.zero;
        
        bg.zPosition = -1
        
        // Finally, add the background to the Scene Graph
        addChild(bg)
        
        zombie.position = CGPoint(x:400, y:400)
        addChild(zombie)
        
    }
     override func update(_ currentTime: TimeInterval) {
        zombie.position = CGPoint(x: zombie.position.x+8, y: zombie.position.y)
    }
    func move(sprite: SKSpriteNode, velocity: CGPoint) {
        let amountToMove = CGPoint(x: velocity.x * CGFloat(dt),
                                   y: velocity.y * CGFloat(dt))
    }
    
}
