package com.example.macstudent.gameday1;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Paint strokePaint = new Paint();
        RectF r = new RectF(230, 200, 60, 400);

        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setColor(Color.BLACK);
        strokePaint.setStrokeWidth(1);

        ImageView imageView = (ImageView) findViewById(R.id.imageView);
        Bitmap b = Bitmap.createBitmap(300,500, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(b);
        Paint paintbrush = new Paint();
        Paint paintdot = new Paint();
        Paint paintarm = new Paint();

        canvas.drawColor(Color.YELLOW);
        paintbrush.setColor(Color.argb(255,255,127,80));
        paintdot.setColor(Color.argb(255,255,255,255));
        paintarm.setColor(Color.argb(255,0,0,0));
        canvas.drawCircle(150,150,50,paintbrush);
        imageView.setImageBitmap(b);

        canvas.drawRoundRect(r,150,200,strokePaint);
        canvas.drawCircle(150,150,5,paintdot);   //nose
        canvas.drawCircle(135,135,5,paintdot);   //eye
        canvas.drawCircle(165,135,5,paintdot);   //eye
        canvas.drawLine(135,165,165,165,paintdot);   //mouth
        canvas.drawLine(150,100,100,100,paintarm);    //arm



    }
}
